import * as BABYLON from '@babylonjs/core';
import * as GUI from '@babylonjs/gui';

export class MenuManager {
  private scene: BABYLON.Scene;
  private onStartGame: () => void;
  private menuTexture: GUI.AdvancedDynamicTexture;

  constructor(scene: BABYLON.Scene, onStartGame: () => void) {
    this.scene = scene;
    this.onStartGame = onStartGame;
  }

  public createMainMenu(): void {
    this.menuTexture = GUI.AdvancedDynamicTexture.CreateFullscreenUI("UI");

    // Create background
    const background = new GUI.Rectangle("background");
    background.width = 1;
    background.height = 1;
    background.thickness = 0;
    background.background = "black";
    background.alpha = 0.8;
    this.menuTexture.addControl(background);

    // Create title
    const title = new GUI.TextBlock("title", "Dark Forest");
    title.fontSize = 80;
    title.color = "red";
    title.fontFamily = "Horror";
    title.top = "-200px";
    this.menuTexture.addControl(title);

    // Create subtitle
    const subtitle = new GUI.TextBlock("subtitle", "A Horror Survival Game");
    subtitle.fontSize = 24;
    subtitle.color = "white";
    subtitle.top = "-120px";
    this.menuTexture.addControl(subtitle);

    // Create start button
    const startButton = GUI.Button.CreateSimpleButton("startButton", "Enter the Darkness");
    startButton.width = "200px";
    startButton.height = "60px";
    startButton.color = "white";
    startButton.thickness = 2;
    startButton.cornerRadius = 20;
    startButton.background = "red";
    startButton.onPointerUpObservable.add(() => {
      this.fadeOutMenu(() => this.onStartGame());
    });
    this.menuTexture.addControl(startButton);

    // Create instructions
    const instructions = new GUI.TextBlock("instructions", 
      "WASD - Move\nSHIFT - Run\nSPACE - Jump\nF - Flashlight\nESC - Pause"
    );
    instructions.fontSize = 18;
    instructions.color = "white";
    instructions.top = "100px";
    this.menuTexture.addControl(instructions);
  }

  private fadeOutMenu(onComplete: () => void): void {
    let alpha = 1;
    const interval = setInterval(() => {
      alpha -= 0.05;
      this.menuTexture.alpha = alpha;
      
      if (alpha <= 0) {
        clearInterval(interval);
        this.menuTexture.dispose();
        onComplete();
      }
    }, 50);
  }
}