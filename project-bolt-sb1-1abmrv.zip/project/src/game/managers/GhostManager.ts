import * as BABYLON from '@babylonjs/core';
import { GameState } from '../state/GameState';
import { Settings } from '../config/Settings';

export class GhostManager {
  private scene: BABYLON.Scene;
  private gameState: GameState;
  private ghost: BABYLON.Mesh;
  private ghostLight: BABYLON.PointLight;
  private ghostParticles: BABYLON.ParticleSystem;
  private lastTeleportTime: number = 0;
  private isVisible: boolean = false;
  private currentBehavior: 'hunt' | 'stalk' | 'teleport' = 'stalk';

  constructor(scene: BABYLON.Scene, gameState: GameState) {
    this.scene = scene;
    this.gameState = gameState;
  }

  public async setup(): Promise<void> {
    await this.createGhost();
    this.setupGhostEffects();
    this.setupGhostBehavior();
  }

  private async createGhost(): Promise<void> {
    // Create ghost mesh
    const ghostMaterial = new BABYLON.StandardMaterial("ghostMaterial", this.scene);
    ghostMaterial.emissiveColor = new BABYLON.Color3(0.2, 0.2, 0.3);
    ghostMaterial.alpha = 0.7;

    // Create basic ghost mesh
    this.ghost = BABYLON.MeshBuilder.CreateBox("ghost", {
      height: 2,
      width: 1,
      depth: 1
    }, this.scene);
    
    this.ghost.material = ghostMaterial;

    // Initial position
    this.ghost.position = this.getRandomPosition();
    this.gameState.ghostPosition = this.ghost.position;
  }

  private setupGhostEffects(): void {
    // Ghost light
    this.ghostLight = new BABYLON.PointLight(
      "ghostLight",
      this.ghost.position,
      this.scene
    );
    this.ghostLight.intensity = 0.5;
    this.ghostLight.diffuse = new BABYLON.Color3(0.1, 0.2, 0.5);
    this.ghostLight.specular = new BABYLON.Color3(0.1, 0.2, 0.5);
    this.ghostLight.range = 10;

    // Ghost particles
    this.ghostParticles = new BABYLON.ParticleSystem("ghostParticles", 2000, this.scene);
    this.ghostParticles.particleTexture = new BABYLON.Texture("textures/smoke.png", this.scene);
    this.ghostParticles.emitter = this.ghost;
    this.ghostParticles.minEmitBox = new BABYLON.Vector3(-1, 0, -1);
    this.ghostParticles.maxEmitBox = new BABYLON.Vector3(1, 2, 1);
    this.ghostParticles.color1 = new BABYLON.Color4(0.1, 0.2, 0.5, 1.0);
    this.ghostParticles.color2 = new BABYLON.Color4(0.2, 0.3, 0.6, 1.0);
    this.ghostParticles.colorDead = new BABYLON.Color4(0, 0, 0.2, 0.0);
    this.ghostParticles.minSize = 0.3;
    this.ghostParticles.maxSize = 0.7;
    this.ghostParticles.minLifeTime = 0.3;
    this.ghostParticles.maxLifeTime = 1.5;
    this.ghostParticles.emitRate = 100;
    this.ghostParticles.blendMode = BABYLON.ParticleSystem.BLENDMODE_ONEONE;
    this.ghostParticles.gravity = new BABYLON.Vector3(0, 0, 0);
    this.ghostParticles.direction1 = new BABYLON.Vector3(-1, 1, -1);
    this.ghostParticles.direction2 = new BABYLON.Vector3(1, 1, 1);
    this.ghostParticles.minAngularSpeed = 0;
    this.ghostParticles.maxAngularSpeed = Math.PI;
    this.ghostParticles.start();
  }

  private setupGhostBehavior(): void {
    this.scene.registerBeforeRender(() => {
      const deltaTime = this.scene.getEngine().getDeltaTime() / 1000;
      this.updateGhostBehavior(deltaTime);
    });
  }

  private updateGhostBehavior(deltaTime: number): void {
    const playerPosition = this.gameState.playerPosition;
    const distanceToPlayer = BABYLON.Vector3.Distance(this.ghost.position, playerPosition);

    // Update ghost position in game state
    this.gameState.ghostPosition = this.ghost.position;

    // Check if it's time to change behavior
    if (this.shouldChangeBehavior(distanceToPlayer)) {
      this.changeBehavior(distanceToPlayer);
    }

    // Execute current behavior
    switch (this.currentBehavior) {
      case 'hunt':
        this.huntBehavior(deltaTime, playerPosition);
        break;
      case 'stalk':
        this.stalkBehavior(deltaTime, playerPosition);
        break;
      case 'teleport':
        this.teleportBehavior();
        break;
    }

    // Update ghost visibility
    this.updateGhostVisibility(distanceToPlayer);

    // Update ghost effects
    this.updateGhostEffects(distanceToPlayer);

    // Check for game over condition
    if (distanceToPlayer < Settings.GHOST_KILL_DISTANCE) {
      this.gameState.isGameOver = true;
    }
  }

  private shouldChangeBehavior(distanceToPlayer: number): boolean {
    const currentTime = Date.now();
    const timeSinceLastTeleport = currentTime - this.lastTeleportTime;

    if (this.currentBehavior === 'teleport') {
      return true; // Always change after teleport
    }

    if (distanceToPlayer < Settings.GHOST_HUNT_DISTANCE && this.currentBehavior !== 'hunt') {
      return true;
    }

    if (timeSinceLastTeleport > Settings.GHOST_TELEPORT_COOLDOWN && Math.random() < 0.01) {
      return true;
    }

    return false;
  }

  private changeBehavior(distanceToPlayer: number): void {
    if (distanceToPlayer < Settings.GHOST_HUNT_DISTANCE) {
      this.currentBehavior = 'hunt';
    } else if (Date.now() - this.lastTeleportTime > Settings.GHOST_TELEPORT_COOLDOWN) {
      this.currentBehavior = 'teleport';
    } else {
      this.currentBehavior = 'stalk';
    }
  }

  private huntBehavior(deltaTime: number, playerPosition: BABYLON.Vector3): void {
    const direction = playerPosition.subtract(this.ghost.position).normalize();
    const speed = Settings.GHOST_HUNT_SPEED * deltaTime;
    
    this.ghost.position.addInPlace(direction.scale(speed));
    this.ghost.lookAt(playerPosition);
  }

  private stalkBehavior(deltaTime: number, playerPosition: BABYLON.Vector3): void {
    const direction = playerPosition.subtract(this.ghost.position).normalize();
    const speed = Settings.GHOST_STALK_SPEED * deltaTime;
    
    // Add some randomness to movement
    const randomOffset = new BABYLON.Vector3(
      (Math.random() - 0.5) * 2,
      0,
      (Math.random() - 0.5) * 2
    );
    
    direction.addInPlace(randomOffset.scale(0.3));
    direction.normalize();
    
    this.ghost.position.addInPlace(direction.scale(speed));
    this.ghost.lookAt(playerPosition);
  }

  private teleportBehavior(): void {
    const newPosition = this.getRandomPosition();
    this.ghost.position = newPosition;
    this.lastTeleportTime = Date.now();
    this.currentBehavior = 'stalk';
  }

  private updateGhostVisibility(distanceToPlayer: number): void {
    const shouldBeVisible = distanceToPlayer < Settings.GHOST_VISIBLE_DISTANCE;
    
    if (shouldBeVisible !== this.isVisible) {
      this.isVisible = shouldBeVisible;
      
      if (this.isVisible) {
        this.ghost.visibility = 0;
        this.scene.beginAnimation(this.ghost, 0, 100, false, 1, () => {
          this.ghost.visibility = 1;
        });
      } else {
        this.scene.beginAnimation(this.ghost, 0, 100, false, 1, () => {
          this.ghost.visibility = 0;
        });
      }
    }
  }

  private updateGhostEffects(distanceToPlayer: number): void {
    // Update light intensity based on distance
    const lightIntensity = Math.max(0, 1 - (distanceToPlayer / Settings.GHOST_VISIBLE_DISTANCE));
    this.ghostLight.intensity = lightIntensity * 0.5;

    // Update particle system
    this.ghostParticles.emitRate = 100 * lightIntensity;
  }

  private getRandomPosition(): BABYLON.Vector3 {
    const angle = Math.random() * Math.PI * 2;
    const distance = Settings.GHOST_SPAWN_DISTANCE_MIN + 
      Math.random() * (Settings.GHOST_SPAWN_DISTANCE_MAX - Settings.GHOST_SPAWN_DISTANCE_MIN);
    
    return new BABYLON.Vector3(
      Math.cos(angle) * distance,
      2,
      Math.sin(angle) * distance
    );
  }
}