import * as BABYLON from '@babylonjs/core';

export class LightningManager {
  private scene: BABYLON.Scene;
  private lightningLight: BABYLON.PointLight;
  private thunderSound: BABYLON.Sound;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public setup(): void {
    // Create lightning light
    this.lightningLight = new BABYLON.PointLight(
      "lightningLight",
      new BABYLON.Vector3(0, 100, 0),
      this.scene
    );
    this.lightningLight.intensity = 0;

    // Create thunder sound
    this.thunderSound = new BABYLON.Sound(
      "thunder",
      "sounds/thunder.mp3",
      this.scene,
      null,
      {
        loop: false,
        autoplay: false
      }
    );

    // Start random lightning
    this.startRandomLightning();
  }

  private startRandomLightning(): void {
    setInterval(() => {
      if (Math.random() < 0.1) {
        this.createLightningStrike();
      }
    }, 20000);
  }

  private async createLightningStrike(): Promise<void> {
    const duration = 200;
    const maxIntensity = 2;

    // Flash 1
    this.lightningLight.intensity = maxIntensity;
    await this.delay(duration);
    this.lightningLight.intensity = 0;
    await this.delay(duration / 2);

    // Flash 2
    this.lightningLight.intensity = maxIntensity * 0.5;
    this.thunderSound.play();
    await this.delay(duration / 2);
    this.lightningLight.intensity = 0;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}