import * as BABYLON from '@babylonjs/core';
import { Settings } from '../config/Settings';

export class EnvironmentManager {
  private scene: BABYLON.Scene;
  private trees: BABYLON.InstancedMesh[] = [];
  private props: BABYLON.Mesh[] = [];
  private fogEnabled: boolean = true;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public async setup(): Promise<void> {
    this.createSkybox();
    this.createGround();
    await this.createTrees();
    await this.createProps();
    this.setupFog();
    this.setupPostProcessing();
  }

  private createSkybox(): void {
    const skybox = BABYLON.MeshBuilder.CreateBox("skybox", { size: 1000 }, this.scene);
    const skyboxMaterial = new BABYLON.StandardMaterial("skyboxMaterial", this.scene);
    skyboxMaterial.backFaceCulling = false;
    skyboxMaterial.reflectionTexture = new BABYLON.CubeTexture(
      "textures/skybox",
      this.scene
    );
    skyboxMaterial.reflectionTexture.coordinatesMode = BABYLON.Texture.SKYBOX_MODE;
    skyboxMaterial.diffuseColor = new BABYLON.Color3(0, 0, 0);
    skyboxMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
    skybox.material = skyboxMaterial;
  }

  private createGround(): void {
    const ground = BABYLON.MeshBuilder.CreateGroundFromHeightMap(
      "ground",
      "textures/heightmap.png",
      {
        width: 1000,
        height: 1000,
        subdivisions: 100,
        minHeight: 0,
        maxHeight: 10
      },
      this.scene
    );

    const groundMaterial = new BABYLON.StandardMaterial("groundMaterial", this.scene);
    groundMaterial.diffuseTexture = new BABYLON.Texture("textures/ground_diffuse.jpg", this.scene);
    groundMaterial.bumpTexture = new BABYLON.Texture("textures/ground_normal.jpg", this.scene);
    groundMaterial.diffuseTexture.uScale = groundMaterial.diffuseTexture.vScale = 100;
    groundMaterial.bumpTexture.uScale = groundMaterial.bumpTexture.vScale = 100;
    ground.material = groundMaterial;
    ground.checkCollisions = true;
  }

  private async createTrees(): Promise<void> {
    // Load tree models
    const treeModels = await Promise.all([
      BABYLON.SceneLoader.ImportMeshAsync("", "models/", "tree1.glb", this.scene),
      BABYLON.SceneLoader.ImportMeshAsync("", "models/", "tree2.glb", this.scene),
      BABYLON.SceneLoader.ImportMeshAsync("", "models/", "tree3.glb", this.scene)
    ]);

    const treeMeshes = treeModels.map(model => model.meshes[0] as BABYLON.Mesh);

    // Create tree instances
    for (let i = 0; i < Settings.TREE_COUNT; i++) {
      const treeIndex = Math.floor(Math.random() * treeMeshes.length);
      const tree = treeMeshes[treeIndex].createInstance(`tree${i}`);

      // Random position
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * Settings.FOREST_RADIUS;
      tree.position = new BABYLON.Vector3(
        Math.cos(angle) * distance,
        0,
        Math.sin(angle) * distance
      );

      // Random rotation and scale
      tree.rotation.y = Math.random() * Math.PI * 2;
      const scale = 0.8 + Math.random() * 0.4;
      tree.scaling = new BABYLON.Vector3(scale, scale, scale);

      tree.checkCollisions = true;
      this.trees.push(tree);
    }
  }

  private async createProps(): Promise<void> {
    // Create basic props using primitive shapes
    const well = BABYLON.MeshBuilder.CreateCylinder("well", {
      height: 3,
      diameter: 2
    }, this.scene);
    well.position = new BABYLON.Vector3(-15, 1.5, 25);
    well.checkCollisions = true;
    this.props.push(well);

    await this.createGraveyard();
    await this.createCampsite();
    await this.createDungeonEntrance();
  }

  private async createGraveyard(): Promise<void> {
    for (let i = 0; i < 12; i++) {
      const tombstone = BABYLON.MeshBuilder.CreateBox(`tombstone${i}`, {
        height: 2,
        width: 1,
        depth: 0.3
      }, this.scene);

      const angle = (i / 12) * Math.PI * 2;
      const distance = 5 + Math.random() * 2;
      
      tombstone.position = new BABYLON.Vector3(
        Math.cos(angle) * distance + 40,
        1,
        Math.sin(angle) * distance + 40
      );
      
      tombstone.rotation.y = Math.random() * Math.PI * 2;
      tombstone.rotation.x = (Math.random() - 0.5) * 0.2;
      tombstone.rotation.z = (Math.random() - 0.5) * 0.2;
      
      tombstone.checkCollisions = true;
      this.props.push(tombstone);
    }
  }

  private async createCampsite(): Promise<void> {
    const tent = BABYLON.MeshBuilder.CreateCylinder("tent", {
      height: 3,
      diameter: 4,
      tessellation: 3
    }, this.scene);
    tent.position = new BABYLON.Vector3(-40, 1.5, -40);
    tent.rotation.z = Math.PI / 2;
    tent.checkCollisions = true;
    this.props.push(tent);
  }

  private async createDungeonEntrance(): Promise<void> {
    const entrance = BABYLON.MeshBuilder.CreateBox("entrance", {
      width: 4,
      height: 6,
      depth: 4
    }, this.scene);
    entrance.position = new BABYLON.Vector3(60, 3, -60);
    entrance.checkCollisions = true;
    this.props.push(entrance);
  }

  private setupFog(): void {
    this.scene.fogMode = BABYLON.Scene.FOGMODE_EXP2;
    this.scene.fogDensity = 0.01;
    this.scene.fogColor = new BABYLON.Color3(0.1, 0.1, 0.15);
  }

  private setupPostProcessing(): void {
    // Film grain effect
    const grain = new BABYLON.ImageProcessingPostProcess(
      "grain",
      1.0,
      this.scene.activeCamera
    );
    grain.grainAmount = 0.1;
    grain.contrast = 1.1;

    // Chromatic aberration
    const chromatic = new BABYLON.ChromaticAberrationPostProcess(
      "chromatic",
      1.0,
      this.scene.activeCamera
    );
    chromatic.aberrationAmount = 1;

    // Vignette
    const pipeline = new BABYLON.DefaultRenderingPipeline(
      "pipeline",
      true,
      this.scene,
      [this.scene.activeCamera]
    );
    pipeline.imageProcessing.vignetteWeight = 1;
    pipeline.imageProcessing.vignetteStretch = 1;
    pipeline.imageProcessing.vignetteColor = new BABYLON.Color4(0, 0, 0, 1);
    pipeline.imageProcessing.vignetteCameraFov = 0.5;
  }

  public toggleFog(): void {
    this.fogEnabled = !this.fogEnabled;
    this.scene.fogDensity = this.fogEnabled ? 0.01 : 0;
  }
}