import * as BABYLON from '@babylonjs/core';

export class HouseManager {
  private scene: BABYLON.Scene;
  private house: BABYLON.Mesh;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public async createHouse(): Promise<void> {
    // Create a simple house mesh
    this.house = BABYLON.MeshBuilder.CreateBox("house", {
      width: 10,
      height: 8,
      depth: 10
    }, this.scene);
    
    this.house.position = new BABYLON.Vector3(0, 4, 0);
    this.house.checkCollisions = true;

    // Add roof
    const roof = BABYLON.MeshBuilder.CreateCylinder("roof", {
      height: 5,
      diameter: 12,
      tessellation: 4
    }, this.scene);
    
    roof.position = new BABYLON.Vector3(0, 8.5, 0);
    roof.rotation.z = Math.PI / 2;
    roof.checkCollisions = true;
  }
}