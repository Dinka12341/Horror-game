import * as BABYLON from '@babylonjs/core';

export class ParticleManager {
  private scene: BABYLON.Scene;
  private fogParticles: BABYLON.ParticleSystem;
  private leafParticles: BABYLON.ParticleSystem;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public setup(): void {
    this.createFogParticles();
    this.createLeafParticles();
  }

  private createFogParticles(): void {
    this.fogParticles = new BABYLON.ParticleSystem("fog", 1000, this.scene);
    this.fogParticles.particleTexture = new BABYLON.Texture("textures/smoke.png", this.scene);
    this.fogParticles.minEmitBox = new BABYLON.Vector3(-100, 0, -100);
    this.fogParticles.maxEmitBox = new BABYLON.Vector3(100, 5, 100);
    this.fogParticles.color1 = new BABYLON.Color4(0.8, 0.8, 0.8, 0.1);
    this.fogParticles.color2 = new BABYLON.Color4(0.95, 0.95, 0.95, 0.15);
    this.fogParticles.colorDead = new BABYLON.Color4(0.9, 0.9, 0.9, 0);
    this.fogParticles.minSize = 3.0;
    this.fogParticles.maxSize = 5.0;
    this.fogParticles.minLifeTime = 5.0;
    this.fogParticles.maxLifeTime = 8.0;
    this.fogParticles.emitRate = 50;
    this.fogParticles.gravity = new BABYLON.Vector3(0, 0.01, 0);
    this.fogParticles.direction1 = new BABYLON.Vector3(-0.2, 0, -0.2);
    this.fogParticles.direction2 = new BABYLON.Vector3(0.2, 0, 0.2);
    this.fogParticles.start();
  }

  private createLeafParticles(): void {
    this.leafParticles = new BABYLON.ParticleSystem("leaves", 300, this.scene);
    this.leafParticles.particleTexture = new BABYLON.Texture("textures/leaf.png", this.scene);
    this.leafParticles.minEmitBox = new BABYLON.Vector3(-100, 10, -100);
    this.leafParticles.maxEmitBox = new BABYLON.Vector3(100, 15, 100);
    this.leafParticles.color1 = new BABYLON.Color4(0.3, 0.5, 0.2, 1.0);
    this.leafParticles.color2 = new BABYLON.Color4(0.4, 0.6, 0.3, 1.0);
    this.leafParticles.colorDead = new BABYLON.Color4(0.3, 0.5, 0.2, 0);
    this.leafParticles.minSize = 0.3;
    this.leafParticles.maxSize = 0.8;
    this.leafParticles.minLifeTime = 5.0;
    this.leafParticles.maxLifeTime = 8.0;
    this.leafParticles.emitRate = 10;
    this.leafParticles.gravity = new BABYLON.Vector3(0, -0.1, 0);
    this.leafParticles.direction1 = new BABYLON.Vector3(-1, -1, -1);
    this.leafParticles.direction2 = new BABYLON.Vector3(1, -1, 1);
    this.leafParticles.minAngularSpeed = -1;
    this.leafParticles.maxAngularSpeed = 1;
    this.leafParticles.start();
  }
}