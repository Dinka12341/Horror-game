import * as BABYLON from '@babylonjs/core';
import * as GUI from '@babylonjs/gui';

export class UIManager {
  private scene: BABYLON.Scene;
  private advancedTexture: GUI.AdvancedDynamicTexture;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public setup(): void {
    this.advancedTexture = GUI.AdvancedDynamicTexture.CreateFullscreenUI("UI");
    this.createHUD();
  }

  private createHUD(): void {
    const keyText = new GUI.TextBlock();
    keyText.text = "Keys: 0/5";
    keyText.color = "white";
    keyText.fontSize = 24;
    keyText.top = "20px";
    keyText.left = "20px";
    this.advancedTexture.addControl(keyText);
  }

  public showGameOver(): void {
    const gameOverText = new GUI.TextBlock();
    gameOverText.text = "GAME OVER";
    gameOverText.color = "red";
    gameOverText.fontSize = 64;
    this.advancedTexture.addControl(gameOverText);
  }

  public showVictory(): void {
    const victoryText = new GUI.TextBlock();
    victoryText.text = "YOU ESCAPED";
    victoryText.color = "green";
    victoryText.fontSize = 64;
    this.advancedTexture.addControl(victoryText);
  }
}