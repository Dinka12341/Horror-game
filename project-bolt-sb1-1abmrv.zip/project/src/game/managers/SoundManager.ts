import * as BABYLON from '@babylonjs/core';

export class SoundManager {
  private scene: BABYLON.Scene;
  private ambientSound: BABYLON.Sound;
  private windSound: BABYLON.Sound;
  private crowSound: BABYLON.Sound;
  private musicSound: BABYLON.Sound;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public setup(): void {
    // Ambient forest sound
    this.ambientSound = new BABYLON.Sound(
      "ambient",
      "sounds/forest_ambient.mp3",
      this.scene,
      null,
      {
        loop: true,
        autoplay: true,
        volume: 0.3
      }
    );

    // Wind sound
    this.windSound = new BABYLON.Sound(
      "wind",
      "sounds/wind.mp3",
      this.scene,
      null,
      {
        loop: true,
        autoplay: true,
        volume: 0.2
      }
    );

    // Crow sound (plays randomly)
    this.crowSound = new BABYLON.Sound(
      "crow",
      "sounds/crow.mp3",
      this.scene,
      null,
      {
        loop: false,
        autoplay: false,
        volume: 0.4
      }
    );

    // Background music
    this.musicSound = new BABYLON.Sound(
      "music",
      "sounds/horror_music.mp3",
      this.scene,
      null,
      {
        loop: true,
        autoplay: true,
        volume: 0.15
      }
    );

    // Setup random crow sounds
    this.setupRandomCrowSounds();
  }

  private setupRandomCrowSounds(): void {
    setInterval(() => {
      if (Math.random() < 0.3) {
        this.crowSound.play();
      }
    }, 20000);
  }

  public stopAll(): void {
    this.ambientSound.stop();
    this.windSound.stop();
    this.crowSound.stop();
    this.musicSound.stop();
  }
}