import * as BABYLON from '@babylonjs/core';

export class WeatherManager {
  private scene: BABYLON.Scene;
  private rainParticles: BABYLON.ParticleSystem;
  private rainSound: BABYLON.Sound;
  private isRaining: boolean = false;

  constructor(scene: BABYLON.Scene) {
    this.scene = scene;
  }

  public setup(): void {
    this.setupRainSystem();
    this.setupRainSound();
    this.startRandomWeather();
  }

  private setupRainSystem(): void {
    this.rainParticles = new BABYLON.ParticleSystem("rain", 10000, this.scene);
    this.rainParticles.particleTexture = new BABYLON.Texture("textures/raindrop.png", this.scene);
    this.rainParticles.minEmitBox = new BABYLON.Vector3(-100, 20, -100);
    this.rainParticles.maxEmitBox = new BABYLON.Vector3(100, 20, 100);
    this.rainParticles.color1 = new BABYLON.Color4(0.5, 0.5, 0.5, 0.5);
    this.rainParticles.color2 = new BABYLON.Color4(0.5, 0.5, 0.5, 0.5);
    this.rainParticles.colorDead = new BABYLON.Color4(0.5, 0.5, 0.5, 0);
    this.rainParticles.minSize = 0.1;
    this.rainParticles.maxSize = 0.3;
    this.rainParticles.minLifeTime = 0.5;
    this.rainParticles.maxLifeTime = 1;
    this.rainParticles.emitRate = 5000;
    this.rainParticles.gravity = new BABYLON.Vector3(0, -9.81, 0);
    this.rainParticles.direction1 = new BABYLON.Vector3(-1, -1, -1);
    this.rainParticles.direction2 = new BABYLON.Vector3(1, -1, 1);
  }

  private setupRainSound(): void {
    this.rainSound = new BABYLON.Sound(
      "rain",
      "sounds/rain.mp3",
      this.scene,
      null,
      {
        loop: true,
        autoplay: false,
        volume: 0.3
      }
    );
  }

  private startRandomWeather(): void {
    setInterval(() => {
      if (Math.random() < 0.3) {
        this.toggleRain();
      }
    }, 60000);
  }

  private toggleRain(): void {
    this.isRaining = !this.isRaining;
    
    if (this.isRaining) {
      this.rainParticles.start();
      this.rainSound.play();
    } else {
      this.rainParticles.stop();
      this.rainSound.stop();
    }
  }
}