import * as BABYLON from '@babylonjs/core';
import { GameState } from '../state/GameState';
import { Settings } from '../config/Settings';

export class PlayerManager {
  private scene: BABYLON.Scene;
  private gameState: GameState;
  private camera: BABYLON.UniversalCamera;
  private cameraRoot: BABYLON.TransformNode;
  private isGrounded: boolean = false;
  private jumpForce: number = 0;
  private stamina: number = 100;
  private isRunning: boolean = false;

  constructor(scene: BABYLON.Scene, gameState: GameState) {
    this.scene = scene;
    this.gameState = gameState;
  }

  public setup(): void {
    this.createCamera();
    this.setupControls();
    this.setupPhysics();
  }

  private createCamera(): void {
    // Create a camera root for smooth rotation
    this.cameraRoot = new BABYLON.TransformNode("cameraRoot", this.scene);
    this.cameraRoot.position = new BABYLON.Vector3(0, Settings.PLAYER_HEIGHT, 0);

    // Create the camera
    this.camera = new BABYLON.UniversalCamera("camera", new BABYLON.Vector3(0, 0, 0), this.scene);
    this.camera.parent = this.cameraRoot;
    this.camera.fov = 1.2;
    this.camera.minZ = 0.1;
    this.camera.maxZ = 100;
    this.camera.inertia = 0.5;
    this.camera.angularSensibility = 1000;

    // Setup camera collision
    this.camera.ellipsoid = new BABYLON.Vector3(1, 2, 1);
    this.camera.checkCollisions = true;
    this.camera.applyGravity = true;

    // Lock pointer
    this.scene.onPointerDown = () => {
      if (!this.scene.alreadyLocked) {
        this.canvas.requestPointerLock();
      }
    };
  }

  private setupControls(): void {
    // Movement controls
    this.scene.onKeyboardObservable.add((kbInfo) => {
      switch (kbInfo.type) {
        case BABYLON.KeyboardEventTypes.KEYDOWN:
          this.handleKeyDown(kbInfo.event.key);
          break;
        case BABYLON.KeyboardEventTypes.KEYUP:
          this.handleKeyUp(kbInfo.event.key);
          break;
      }
    });

    // Mouse look
    this.scene.onPointerMove = (evt) => {
      if (this.scene.alreadyLocked) {
        const dx = evt.movementX || evt.mozMovementX || evt.webkitMovementX || 0;
        const dy = evt.movementY || evt.mozMovementY || evt.webkitMovementY || 0;
        
        this.cameraRoot.rotation.y += dx * 0.002 * this.camera.angularSensibility;
        this.camera.rotation.x += dy * 0.002 * this.camera.angularSensibility;
        
        // Clamp vertical rotation
        const upperLimit = Math.PI / 2 * 0.9;
        const lowerLimit = -Math.PI / 2 * 0.9;
        this.camera.rotation.x = BABYLON.Scalar.Clamp(this.camera.rotation.x, lowerLimit, upperLimit);
      }
    };
  }

  private setupPhysics(): void {
    // Ray for ground check
    const rayStart = this.cameraRoot.position;
    const rayEnd = rayStart.add(new BABYLON.Vector3(0, -Settings.PLAYER_HEIGHT - 0.1, 0));
    const ray = new BABYLON.Ray(rayStart, rayEnd.subtract(rayStart), Settings.PLAYER_HEIGHT + 0.1);
    
    // Update physics
    this.scene.registerBeforeRender(() => {
      const hit = this.scene.pickWithRay(ray);
      this.isGrounded = hit && hit.distance <= Settings.PLAYER_HEIGHT + 0.1;

      if (this.isGrounded) {
        this.jumpForce = 0;
      } else {
        this.jumpForce -= Settings.GRAVITY * this.scene.getEngine().getDeltaTime() / 1000;
        this.cameraRoot.position.y += this.jumpForce;
      }

      // Update stamina
      if (this.isRunning && this.stamina > 0) {
        this.stamina -= Settings.STAMINA_DRAIN_RATE * this.scene.getEngine().getDeltaTime() / 1000;
      } else if (!this.isRunning && this.stamina < 100) {
        this.stamina += Settings.STAMINA_REGEN_RATE * this.scene.getEngine().getDeltaTime() / 1000;
      }
    });
  }

  private handleKeyDown(key: string): void {
    switch(key.toLowerCase()) {
      case "w":
      case "s":
      case "a":
      case "d":
        this.move(key.toLowerCase());
        break;
      case " ":
        this.jump();
        break;
      case "shift":
        this.isRunning = true;
        break;
    }
  }

  private handleKeyUp(key: string): void {
    if (key.toLowerCase() === "shift") {
      this.isRunning = false;
    }
  }

  private move(direction: string): void {
    const speed = this.isRunning && this.stamina > 0 ? Settings.PLAYER_RUN_SPEED : Settings.PLAYER_WALK_SPEED;
    const forward = this.camera.getDirection(BABYLON.Vector3.Forward());
    const right = this.camera.getDirection(BABYLON.Vector3.Right());
    
    let moveVector = new BABYLON.Vector3(0, 0, 0);

    switch(direction) {
      case "w":
        moveVector.addInPlace(forward.scale(speed));
        break;
      case "s":
        moveVector.addInPlace(forward.scale(-speed));
        break;
      case "a":
        moveVector.addInPlace(right.scale(-speed));
        break;
      case "d":
        moveVector.addInPlace(right.scale(speed));
        break;
    }

    this.cameraRoot.position.addInPlace(moveVector);
  }

  private jump(): void {
    if (this.isGrounded) {
      this.jumpForce = Settings.JUMP_FORCE;
      this.isGrounded = false;
    }
  }

  public getPosition(): BABYLON.Vector3 {
    return this.cameraRoot.position;
  }

  public getRotation(): BABYLON.Vector3 {
    return this.cameraRoot.rotation;
  }
}