import * as BABYLON from '@babylonjs/core';
import * as GUI from '@babylonjs/gui';
import { SoundManager } from './managers/SoundManager';
import { ParticleManager } from './managers/ParticleManager';
import { LightningManager } from './managers/LightningManager';
import { WeatherManager } from './managers/WeatherManager';
import { MenuManager } from './managers/MenuManager';
import { PlayerManager } from './managers/PlayerManager';
import { GhostManager } from './managers/GhostManager';
import { EnvironmentManager } from './managers/EnvironmentManager';
import { CollisionManager } from './managers/CollisionManager';
import { InteractionManager } from './managers/InteractionManager';
import { HouseManager } from './managers/HouseManager';
import { KeyManager } from './managers/KeyManager';
import { UIManager } from './managers/UIManager';
import { GameState } from './state/GameState';
import { Assets } from './config/Assets';

export class Game {
  private canvas: HTMLCanvasElement;
  private engine: BABYLON.Engine;
  private scene: BABYLON.Scene;
  private gameState: GameState;
  private managers: {
    sound: SoundManager;
    particle: ParticleManager;
    lightning: LightningManager;
    weather: WeatherManager;
    menu: MenuManager;
    player: PlayerManager;
    ghost: GhostManager;
    environment: EnvironmentManager;
    collision: CollisionManager;
    interaction: InteractionManager;
    house: HouseManager;
    key: KeyManager;
    ui: UIManager;
  };

  constructor() {
    this.canvas = document.getElementById('renderCanvas') as HTMLCanvasElement;
    this.engine = new BABYLON.Engine(this.canvas, true);
    this.gameState = new GameState();
    this.initializeGame();
  }

  private async initializeGame(): Promise<void> {
    await this.loadAssets();
    this.createMainMenu();
  }

  private async loadAssets(): Promise<void> {
    this.scene = new BABYLON.Scene(this.engine);
    await Assets.loadAll(this.scene);
  }

  private createMainMenu(): void {
    this.scene = new BABYLON.Scene(this.engine);
    this.managers = {
      sound: new SoundManager(this.scene),
      particle: new ParticleManager(this.scene),
      lightning: new LightningManager(this.scene),
      weather: new WeatherManager(this.scene),
      menu: new MenuManager(this.scene, () => this.startGame()),
      player: new PlayerManager(this.scene, this.gameState),
      ghost: new GhostManager(this.scene, this.gameState),
      environment: new EnvironmentManager(this.scene),
      collision: new CollisionManager(this.scene),
      interaction: new InteractionManager(this.scene, this.gameState),
      house: new HouseManager(this.scene),
      key: new KeyManager(this.scene, this.gameState),
      ui: new UIManager(this.scene)
    };
    this.managers.menu.createMainMenu();
  }

  private async startGame(): Promise<void> {
    this.scene = new BABYLON.Scene(this.engine);
    await this.initializeManagers();
    this.setupGameLoop();
  }

  private async initializeManagers(): Promise<void> {
    // Initialize all game managers
    await this.managers.environment.setup();
    await this.managers.house.createHouse();
    await this.managers.key.createKeys();

    // Setup player and ghost
    this.managers.player.setup();
    this.managers.ghost.setup();

    // Setup weather and effects
    this.managers.weather.setup();
    this.managers.lightning.setup();

    // Setup collisions and interactions
    this.managers.collision.setup();
    this.managers.interaction.setup();

    // Setup UI
    this.managers.ui.setup();
  }

  private setupGameLoop(): void {
    this.engine.runRenderLoop(() => {
      this.update();
      this.scene.render();
    });

    window.addEventListener('resize', () => {
      this.engine.resize();
    });
  }

  private update(): void {
    const deltaTime = this.engine.getDeltaTime() / 1000;

    // Update all managers
    Object.values(this.managers).forEach(manager => {
      if (manager.update) {
        manager.update(deltaTime);
      }
    });

    // Check win/lose conditions
    this.checkGameConditions();
  }

  private checkGameConditions(): void {
    if (this.gameState.isGameOver) {
      this.managers.ui.showGameOver();
      this.engine.stopRenderLoop();
    } else if (this.gameState.isVictory) {
      this.managers.ui.showVictory();
      this.engine.stopRenderLoop();
    }
  }
}