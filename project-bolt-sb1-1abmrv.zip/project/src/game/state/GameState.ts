import * as BABYLON from '@babylonjs/core';

export class GameState {
  public playerPosition: BABYLON.Vector3 = BABYLON.Vector3.Zero();
  public ghostPosition: BABYLON.Vector3 = BABYLON.Vector3.Zero();
  public collectedKeys: number = 0;
  public isGameOver: boolean = false;
  public isVictory: boolean = false;
  public currentPhase: 'menu' | 'game' | 'end' = 'menu';
}